import kotlinx.coroutines.*
fun main() {
    runBlocking{
    println("Weather forecast")
    println(getWeatherReport())
    println("Have a good day!")
    }
}


suspend fun printForecast():String{
    delay(1000)
    return "Sunny"
}

suspend fun printTemperature():String{
    delay(500)
    return "30\u00b0C"
}

suspend fun getWeatherReport() = coroutineScope{
            val forecast:Deferred<String> = async{
                  printForecast()
        val temperature:Deferred<String> = async{
            printTemperature()
        }
        delay(200)
        temperature.cancel()
        println("${forecast.await()}")
    
}
                }
       