import kotlinx.coroutines.*
fun main() {
    println("${Thread.currentThread().name} - runBlocking function")
    runBlocking{
    launch{
        println("${Thread.currentThread().name} - runBlocking function")
        withContext(Dispatchers.Default){
        println("${Thread.currentThread().name} - runBlocking function")
        delay(1000)
        println("10 results found.")
    }
        println("${Thread.currentThread().name} - runBlocking function")
    }
    println("Loading...")
   
    }
}



       