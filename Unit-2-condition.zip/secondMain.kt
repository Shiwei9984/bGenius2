fun main(){
  val x = 11
  // when(x){
  //   2->println("x is a prime number between 1 to 10")
  //   3->println("x is a prime number between 1 to 10")
  //   5->println("x is a prime number between 1 to 10")
  //   7->println("x is a prime number between 1 to 10")
  //   else->println("x is not a prime number between 1 to 10")
  // }
  when(x){
    2,3,5,7 -> println("x is a prime number between 1 to 10")
    in 1..10 ->println("x is a number between 1 to 10 but not a prime number")
    is Int("x is a number but not between 1 to 10")
    else -> println("x is not a number)
  }
}