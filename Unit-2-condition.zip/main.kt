fun main() {
  //println(1==1)
  val trafficLightColor = "Yellow"
  // if(trafficLightColor == "Red") {
  //   println("Stop")
  // }
  // else if(trafficLightColor =="Yellow"){
  //   println("Slow")
  // }
  // else if(trafficLightColor=="Green"){
  //   println("Go")
  // }
val message = 
  when(trafficLightColor){
    "Red"->"Stop"
    "Yellow", "Amber"->"Slow"
    "Green"->"Go"
    else-> "Invalid traffic-light color"
  }
  println(message)
}